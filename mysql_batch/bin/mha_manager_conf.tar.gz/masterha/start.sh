nohup sh /etc/masterha/mha_helper.sh > /etc/masterha/app1/helper.log 2>&1 &
